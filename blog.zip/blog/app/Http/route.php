<?php 
Route::resource('itemCRUD','ItemCRUDController');