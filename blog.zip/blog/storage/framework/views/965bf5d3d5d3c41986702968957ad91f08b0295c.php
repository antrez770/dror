<html>
  <head>
   <title>Laravel CRUD Application using Ajax without Reloading Page</title>  
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"> 
  </head>
<body>

<div class="container">
<div class="panel panel-primary">
 <div class="panel-heading">משימות
 <button id="btn_add" name="btn_add" class="btn btn-default pull-right">+</button>
    </div>
      <div class="panel-body"> 
       <table class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>שם</th>
            <th>פרוט</th>
            <th>פעולות</th>
          </tr>
         </thead>
         <tbody id="products-list" name="products-list">
           <?php foreach($products as $product): ?>
            <tr id="product<?php echo e($product->id); ?>">
             <td><?php echo e($product->id); ?></td>
             <td><?php echo e($product->name); ?></td>
             <td><?php echo e($product->details); ?></td>
              <td>
              <button class="btn btn-warning btn-detail open_modal" value="<?php echo e($product->id); ?>">ערוך</button>
              <button class="btn btn-danger btn-delete delete-product" value="<?php echo e($product->id); ?>">X</button>
              </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        </table>
       </div>
       </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
           <div class="modal-content">
             <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">מוצר</h4>
            </div>
            <div class="modal-body">
            <form id="frmProducts" name="frmProducts" class="form-horizontal" novalidate="">
                <div class="form-group error">
                 <label for="inputName" class="col-sm-3 control-label">שם</label>
                   <div class="col-sm-9">
                    <input type="text" class="form-control has-error" id="name" name="name" placeholder="Product Name" value="">
                   </div>
                   </div>
                 <div class="form-group">
                 <label for="inputDetail" class="col-sm-3 control-label">פרוט</label>
                    <div class="col-sm-9">
                    <input type="text" class="form-control" id="details" name="details" placeholder="details" value="">
                    </div>
                </div>
            </form>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-primary" id="btn-save" value="add">שמור שינויים</button>
            <input type="hidden" id="product_id" name="product_id" value="0">
            </div>
        </div>
      </div>
  </div>
</div>
    <meta name="_token" content="<?php echo csrf_token(); ?>" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('js/ajaxscript.js')); ?>"></script>
</body>
</html>