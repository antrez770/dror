<?php 

$errorContainer = array();
$passw ='anton123';
$email = 'antrez770@gmail.com';

$arrayFields = array(

    'email_user' => $_POST['email_user'],
    'password_user' => $_POST['password_user']

);
 

foreach($arrayFields as $fieldName => $oneField){
    if($oneField == '' || !isset($oneField)){
        $errorContainer[$fieldName] = 'The Fild is requierd';
    }
}
 

if($arrayFields['password_user'] != $passw)
    $errorContainer['password_user'] = 'The password is not correct';
 else if($arrayFields['email_user'] != $email)
    $errorContainer['email_user'] = 'The email is not correct';

if(empty($errorContainer)){

    echo json_encode(array('result' => 'success'));
}else{

    echo json_encode(array('result' => 'error', 'text_error' => $errorContainer));    
}

