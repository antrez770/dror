<?php
$result = ["status" => "success"];
if ($_POST['email'] != 'frontend@gollgi.com') {
    $result["status"] = "error";
    $result["message"] = "user not exists";
} else if ($_POST['password'] != 'gollgi') {
    $result["status"] = "error";
    $result["message"] = "incorrect password";
}

echo json_encode($result);