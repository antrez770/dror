(function ($) {
	$('.form-js-label').find('input').on('input', function (e) {
  $(e.currentTarget).attr('data-empty', !e.currentTarget.value);
});
	})(jQuery);
